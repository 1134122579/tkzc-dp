<template>
  <div class="home">
    <div class="nav" ref="nav">
      <div class="logo">
        <el-image :src="logo" style="width: 100%; height: 100%"></el-image>
      </div>
      <!-- 选项 -->
      <el-menu
        mode="horizontal"
        class="menudie"
        :default-active="activeIndex"
        @select="handleSelect"
        :background-color="backgroundcolor"
        :active-text-color="textcolor"
        :text-color="textcolor"
      >
        <el-submenu
          popper-class="submenuStyle"
          v-for="item in navlist"
          :key="item.id"
          v-if="item.children.length > 0"
          :index="item.id"
        >
          <template slot="title"> {{ item.title }} </template>
          <el-menu-item
            v-for="childrenitem in item.children"
            :index="childrenitem.id"
            :key="childrenitem.id"
            >{{ childrenitem.title }}</el-menu-item
          >
        </el-submenu>
        <el-menu-item
          popper-class="submenuStyle"
          v-for="item in navlist"
          :key="item.id"
          v-if="item.children.length <= 0"
          :index="item.id"
          >{{ item.title }}</el-menu-item
        >
      </el-menu>
    </div>
    <!-- 设计案例 -->

    <div class="SwiperModelStyle" v-if="tabId == 2">
      <!-- 轮播内容-->
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide" v-for="item in list" :key="item.id">
            <div class="swiperContent" :style="item.img | filterBack">
              <!-- <div class="swiperContent_text">
                <h5>{{ item.name || "我是标题" }}</h5>
                <p>我是内容介绍</p>
              </div> -->
            </div>
          </div>
        </div>
        <!--分页器。如果放置在swiper-container外面，需要自定义样式。-->
        <div class="swiper-pagination"></div>
        <!--分页器。如果放置在swiper-container外面，需要自定义样式。-->
        <!-- 翻页 -->
        <!-- 翻页 -->
        <div class="dropdownStyle">
          <div class="flexStyle">
            <div class="flexStylebutton">
              <div class="swiperbuttonprev" slot="button-prev">
                <i class="el-icon-caret-left"></i>
              </div>
              <div class="swiperbuttonnext" slot="button-next">
                <i class="el-icon-caret-right"></i>
              </div>
            </div>
            <!-- @click="typebutton" -->
            <p class="swipername">{{ value }}</p>
            <!-- v-show="istypelist" -->
            <ul class="typeList">
              <li
                v-for="item in sonlist"
                :key="item.id"
                @click="sureType(item)"
              >
                {{ item.name }}
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- 天空之橙 -->
    <div class="tkzc_home" v-if="tabId == 1">
      <!-- :src="videourl" -->
      <video
        src="http://video.greatorange.cn/zm_design.mp4"
        class="video"
        autoplay
        loop
        muted
        object-fit="cover"
      ></video>
      <div class="Desigin">
        <div class="Desiginbutton" @click="goDesigin">天空之橙Desigin</div>
      </div>
    </div>

    <!--集团动态 -->

    <!-- 联系我们 -->
    <div class="tkzcabout" v-if="tabId == 4">
      <ChinaEcharts />
    </div>
  </div>
</template>

<script>
import Swiper from "swiper"; // 引入swiper依赖  在使用过程中我发现有时候开头字母大写可以成功 、有时候小写 若报错就换成另一个，两者引入取其一
import logo from "@/assets/logo.png";
import videourl from "@/assets/tkzc.mp4";

import { getTopClass, getClass, getFlimList } from "@/api/swiperApi.js";
import ChinaEcharts from "@/components/ChinaEcharts.vue";

export default {
  name: "carrousel",
  filters: {
    filterBack(data) {
      return `background-image: url('${data}')`;
    },
  },
  components: {
    ChinaEcharts,
  },
  data() {
    return {
      videourl,
      tabId: "1",
      activeIndex: "1-1",
      textcolor: "#fdb732",
      backgroundcolor: "rgba(0,0,0,.3)",
      value: "",
      logo,
      type: 2,
      swiperconfig: {
        //是否循环
        speed: 1200, //默认就是300毫秒
        // loopAdditionalSlides: 1,
        loop: true,
        observer: true,
        // mousewheel: true,
        effect: "cards", //切换效果"fade"（淡入）、"cube"（方块）、"coverflow"（3d流）、"flip"（3d翻转）、"cards"(cards)、"creative"（创意性
        // cubeEffect: {
        //   shadow: true,
        //   slideShadows: true,
        //   shadowOffset: 20,
        //   shadowScale: 0.94,
        // },
        keyboard: {
          enabled: true,
          onlyInViewport: true,
        },
        fadeEffect: {
          crossFade: true,
        },
        autoplay: {
          //swiper手动滑动之后自动轮播失效的解决方法,包括触碰，拖动，点击pagination,重新启动自动播放
          //   disableOnInteraction: false,
          disableOnInteraction: false,
          // 自动播放时间：毫秒
          delay: 3000,
        },
        // pagination: {
        //   //小圆点
        //   el: ".swiper-pagination",
        // },
        navigation: {
          prevEl: ".el-icon-caret-left",
          nextEl: ".el-icon-caret-right",
        },
      },
      navheight: null,
      list: [],
      sonlist: [],
      classList: [],
      swipercaeated: [],
      navlist: [
        {
          id: "1",
          title: "天空之橙Desigin",
          children: [
            {
              id: "1-1",
              title: "关于我们",
            },
            {
              id: "1-2",
              title: "集团构架",
            },
            {
              id: "1-3",
              title: "精英团队",
            },
          ],
        },

        {
          id: "2",
          title: "设计案例",
          children: [],
        },
        {
          id: "3",
          title: "集团动态",
          children: [],
        },
        {
          id: "4",
          title: "联系我们",
          children: [],
        },
      ],
    };
  },
  created() {},

  mounted() {
    this.getTopClass();
    this.getFlimList();
    if (this.tabId == 2) {
      this.getBanner(); //轮播
    }
    if (this.activeIndex.split("-")[0] == 2) {
      this.getClass(this.activeIndex.split("-")[1]);
    } else {
      //   this.getFlimList();
    }
    // document.onclick =
    //   document.onkeydown =
    //   document.onmousemove =
    //     function () {
    //       (document.body || document.documentElement).requestFullscreen();
    //     };
    // document.onclick();
  },
  methods: {
    goDesigin() {
      this.tabId = 2;
      this.value = this.classList[0].title;
      this.activeIndex = this.classList[0].id;
      this.getFlimList(this.classList[0].pid);
      this.getClass(this.activeIndex.split("-")[1]);
    },
    //   切换分类
    sureType(item) {
      console.log(item);
      this.value = item.name;
      this.getFlimList(item.id);
    },
    //封装轮播函数
    getBanner() {
      //调用延迟加载 $nextTick
      let that = this;

      this.swiperconfig.on = {
        reachEnd: function () {
          console.log("到了最后一个slide");
        },
      };
      this.$nextTick(() => {
        that.swipercaeated = new Swiper(".swiper-container", this.swiperconfig);
        // let slide = this.swipercaeated.slides.eq(0);
        // slide.addClass("ani-slide");
      });
    },
    getdomStyle() {
      let { offsetHeight } = this.$refs["nav"];
      console.log(offsetHeight);
      this.navheight = offsetHeight;
    },
    carouselprev() {
      console.log(this.$refs["carousel"]);
      this.$refs["carousel"].prev();
    },
    carouselnext() {
      this.$refs["carousel"].next();
    },
    // 获取 getTopClass
    async getTopClass() {
      let res = await getTopClass();

      res = res.map((item) => {
        item["pid"] = item["id"];
        item["id"] = "2-" + item["id"];
        item["title"] = item["name"];
        return item;
      });
      let index = this.navlist.findIndex((item) => item.title == "设计案例");
      this.classList = res;
      console.log(this.classList);
      this.$nextTick(() => {
        this.navlist[index].children = res;
      });
    },

    async getClass(pid) {
      console.log(pid);
      let res = await getClass({ pid });
      console.log(res, pid);
      this.sonlist = res;
    },
    async getFlimList(class_id = "") {
      let res = await getFlimList(class_id && { class_id });
      this.list = res;
      console.log(this.list);
      this.swipercaeated.autoplay.start(); //自动播放
      this.swipercaeated.updateSlides(); //更新slide
      this.swipercaeated.setGrabCursor(); //关闭鼠标的抓手形状。 unsetGrabCursor()
      this.swipercaeated.update();
      console.log(this.swipercaeated);
    },

    handleSelect(key, keyPath) {
      console.log(key.split("-"), keyPath);
      this.tabId = keyPath[0];
      if (keyPath[0] == 2) {
        let array = this.classList.filter((item) => item.id == key);
        this.getClass(key.split("-")[1]);
        this.getFlimList(key.split("-")[1]);
        this.value = array[0].title;
      } else {
        this.sonlist = [];
      }
    },
  },
};
</script>
<style lang="scss">
.home {
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  position: relative;
  background: #333;
  //   头部
  .nav {
    position: absolute;
    top: 30px;
    z-index: 10;
    width: 100%;
    display: flex;
    justify-content: space-between;
    padding: 0 5rem;
    align-items: center;
    box-sizing: border-box;
    .logo {
      height: 30px;
      padding: 30px 0;
      img {
        // width: 100%;
        height: 100%;
      }
    }
    .navList {
      display: flex;
      justify-content: flex-start;
      .navli {
        width: 160px;
        height: 40px;
        text-align: center;
        // background: #edeceb;
        margin-left: 20px;
        color: #fff;
        font-size: 16px;
        font-weight: bold;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        .icon-sanjiao {
          font-size: 12px;
          transform: scale(0.5);
          margin-left: 5px;
        }
      }
      .navblock {
        position: absolute;
        top: 40px;
        width: 100%;
        li {
          display: flex;
          justify-content: center;
          align-items: center;
          background: #e37a11;
          height: 40px;
          margin-top: 4px;
        }
      }
      :hover {
        background: #e37a11;
      }
    }
    .context {
      background: burlywood;
    }
  }
  .app-content {
    flex: 1;
    width: 100%;
    position: relative;
    background: #333;
    .carouselSyle {
      height: 100%;
      .el-carousel__container {
        height: 100%;
        .imgallstyle {
          width: 100vw;
          height: 100%;
          display: flex;
          justify-content: center;
          align-items: center;
          .imgstyle {
            width: 100%;
            display: block;
          }
        }
      }
    }
  }
  //   设计案例
  .SwiperModelStyle {
    width: 100%;
    height: 100%;
    position: relative;
    .swiper-container {
      width: 100%;
      height: 100%;
      .swiper-wrapper {
        width: 100%;
        height: 100%;
        position: relative;
      }
      //   翻页
      .dropdownStyle {
        width: 100%;
        display: flex;
        justify-content: flex-end;
        position: absolute;
        z-index: 55;
        bottom: 100px;
        right: 60px;
        height: 60px;
        // border-radius: 5px;
        .flexStyle {
          display: flex;
          align-items: center;
          width: 260px;
          font-size: 20px;
          line-height: 1.5;
          //   border: 1px solid #595656;
          text-align: center;
          font-weight: 600;
          position: relative;
          background: rgba(0, 0, 0, 0.35);
          p {
            padding: 0;
            margin: 0;
            width: 100%;
            display: inline-block;
            color: #fff;
          }
          &:hover .typeList {
            display: block;
          }
          .swipername {
            padding: 0 10px;
          }
          .typeList {
            display: none;
            position: absolute;
            width: 100%;
            bottom: 60px;
            height: 400px;
            overflow-y: scroll;
            background: rgba(0, 0, 0, 0.4);
            color: #fff;
            line-height: 1.5;
            overflow-x: hidden;
            font-size: 20px;
            li {
              padding: 10px 0;
              overflow-x: hidden;
              word-wrap: normal;
              &:hover {
                background: #fdb732;
                color: #595656;
              }
            }
            /*修改某个div的滚动条样式*/
            &::-webkit-scrollbar {
              width: 5px;
              height: 5px;
              /**/
            }
            &::-webkit-scrollbar-track {
              background: #fff;
              border-radius: 2px;
            }
            &::-webkit-scrollbar-thumb {
              background: #fdb732;
              border-radius: 10px;
            }
            &::-webkit-scrollbar-thumb:hover {
              background: #999;
            }
            &::-webkit-scrollbar-corner {
              background: #204754;
            }
          }
          .flexStylebutton {
            background: #595656;
            width: 60px;
            height: 100%;
            flex-shrink: 0;
            font-size: 25px;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        }
      }
    }
  }
  .swiperContent {
    display: flex;
    justify-content: center;
    align-items: flex-start;
    flex-direction: column;
    width: 100%;
    height: 100%;
    background-size: cover;
    background-position: 50%;
    background-repeat: no-repeat;
    .swiperContent_text {
      margin-left: 40px;
      padding: 20px;
      background: rgba(0, 0, 0, 0.2);
      width: 250px;
      height: 180px;
      color: #fff;
      font-size: 18px;
      h5 {
        font-size: 30px;
        line-height: 1.5;
      }
    }
    .swiper-slide {
      transform: translateX(-200px);
      opacity: 0;
      transition: all 0.4s;
    }
    .ani-slide {
      transform: translateX(0);
      opacity: 1;
    }
  }
  // 首页
  .tkzc_home {
    width: 100%;
    height: 100%;
    background: #fff;
    position: relative;
    video {
      max-width: 100%;
      max-height: 100%;
      object-fit: cover;
    }
    .video {
      height: auto;
      max-width: 100%;
      width: 100%;
      height: 100%;
    }
    .Desigin {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      margin: auto;
      display: flex;
      justify-content: center;
      align-items: center;
      .Desiginbutton {
        font-size: 30px;
        border-radius: 200px;
        border: 3px solid #ccc;
        width: 400px;
        height: 80px;
        line-height: 80px;
        background: rgba(0, 0, 0, 0.4);
        color: #fff;
        margin-top: 300px;
        &:hover {
          background: #e37a11;
        }
      }
    }
  }
  //   联系我
  .tkzcabout {
    width: 100%;
    height: 100%;
    background: #fff;
    position: relative;
  }
}
</style>

<style lang="scss">
.el-menu--horizontal .el-menu .el-menu-item,
.el-menu--horizontal .el-menu .el-submenu__title {
  text-align: center;
  height: 80px;
  line-height: 40px;
}
.nav {
  .menudie {
    border: none !important;
    .el-submenu {
      background: rgba(0, 0, 0, 0.2);
      width: 200px;
      //   margin-right: 10px;
    }
    .el-menu-item {
      font-size: 20px;
      width: 200px;
    }
    .is-active {
      background: rgba(0, 0, 0, 0.8);
    }
    .submenuStyle {
      font-size: 20px;
      .el-menu {
        .el-menu-item {
          text-align: center;
        }
      }
    }
  }
  .el-submenu__title {
    font-weight: 600;
    font-size: 18px;
    // width: 180px;
    text-align: center;
    &:hover {
      background: #ff0000;
    }
  }
}
/* 整个滚动条 */
::-webkit-scrollbar {
  width: 1px;
  //   height: 0px;
}

/* 滚动条有滑块的轨道部分 */
::-webkit-scrollbar-track-piece {
  background-color: transparent;
  border-radius: 5px;
}

/* 滚动条滑块(竖向:vertical 横向:horizontal) */
::-webkit-scrollbar-thumb {
  cursor: pointer;
  background-color: #f2f2f2;
  border-radius: 5px;
}

/* 滚动条滑块hover */
::-webkit-scrollbar-thumb:hover {
  background-color: #999999;
}

/* 同时有垂直和水平滚动条时交汇的部分 */
::-webkit-scrollbar-corner {
  display: block; /* 修复交汇时出现的白块 */
}
</style>
